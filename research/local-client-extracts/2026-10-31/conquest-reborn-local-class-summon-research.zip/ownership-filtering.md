# DBM-CoA ownership classification notes (local files only)

## Evidence inspected

- `Interface/AddOns/DBM-CoA-Learner/LiveLearning.lua:17-29` parses creature/vehicle GUIDs and requires NPC type, hostile reaction, no player-control bit, no pet/guardian type bits, and no mine/party/raid affiliation bits. It declines to learn when flags/bit library are unavailable.
- `Interface/AddOns/DBM-CoA-Learner/LiveLearning.lua:92-99` consumes CLEU source GUID/name/flags and keeps observations by GUID+spell.
- `Interface/AddOns/DBM-CoA-Learner/Learner.lua:583` accepts multiple CLEU event types, including `SPELL_SUMMON`; it is a distinct learner path and must use the same ownership gate.
- `Interface/AddOns/APIDocumentation/Documentation/CombatLogDocumentation.lua` documents `CombatLog_Object_IsA`, `UnitGUID`, `COMBAT_LOG_EVENT_UNFILTERED`, and the client event API. It does not by itself establish CR-specific ownership semantics.
- `Interface/AddOns/Details/classes/container_pets.lua:20-47,164-216,231-309` tracks pet GUID, owner GUID/flags, summon spell ID, and unit pet tokens.
- `Interface/AddOns/AscensionLogsCompanion/Capture/PetTracker.lua:17-22,48-80` pairs owner/pet unit-token GUIDs on `UNIT_PET` and roster/combat events; its comments say slot-less guardians/totems require other event inference.
- `Interface/AddOns/NecroMinions/NecroMinions.lua:1000-1043` uses source flags and `SPELL_SUMMON` source/destination GUID plus spell ID for live Necromancer minion attribution.

## Suggested DBM-CoA state model

For each combat entity GUID, keep a small encounter-local record: `classification`, `ownerGUID`, `summonSpellID`, `firstSeen`, `lastSeen`, `sourceEvidence`, and `confidence`. Populate it from `UNIT_PET` owner/pet pairs, `SPELL_SUMMON` (source is summoner; destination is summoned entity), and reliable CLEU flags. Clear it on death, encounter reset, and zone change. Do not infer ownership solely from NPC ID or its name.

Classify as hostile NPC only when source flags consistently indicate NPC type and hostile reaction, while excluding player control, pet/guardian type, and player/group affiliation. Use the client `CombatLog_Object_IsA` masks/constants where available; preserve raw source flags for audit. Check `COMBATLOG_OBJECT_CONTROL_PLAYER`, `COMBATLOG_OBJECT_TYPE_PET`, and `COMBATLOG_OBJECT_TYPE_GUARDIAN`; do not treat hostile reaction alone as proof of being a boss.

If flags are absent, contradictory, or the GUID is not recognized, put the event into a bounded review/quarantine bucket with the raw event fields. Do not silently discard it and do not promote it to a boss mechanic. Use NPC ID as a supporting lookup only. Allow an explicit encounter module to retain a known boss ability even if an entity later appears controlled/charmed, but tag that exception with its encounter-specific evidence.

## Candidate-specific limits

`ResearchIndex.lua` is a local observation-derived list explicitly marked unconfirmed. It is not a runtime ownership table. The class and entity crosswalk in this package uses local addon mapping and a preserved reference DB; it must not become a universal blacklist without live GUID/flag confirmation.

No gameplay test or live combat log was run for this package.
